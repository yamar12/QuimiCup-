# Estudos Químicos - Projeto React (Vite + Tailwind)

Conteúdo:
- Código fonte em /src
- Tabela periódica completa em /src/data/periodic.json

Para executar localmente:
1. Instala Node.js (v18+ recomendado).
2. Na pasta do projeto, instala dependências:
   npm install
3. Executa em modo dev:
   npm run dev
4. Faz build:
   npm run build
5. Pré-visualiza build:
   npm run preview

Notas:
- Este template usa Vite + React + Tailwind. O ficheiro periodic.json contém 118 elementos (símbolo, nome, número e massa).
- Personaliza estilos em src/styles.css.

Feito com carinho 💖
