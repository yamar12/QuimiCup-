
import React, { useEffect, useState } from 'react';
import periodic from './data/periodic.json';

export default function App() {
  const [view, setView] = useState('home'); // home | table | lessons | quiz | flashcards
  const [dark, setDark] = useState(false);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    if (dark) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [dark]);

  return (
    <div className="">
      <header className="max-w-6xl mx-auto p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-indigo-500 to-fuchsia-500 flex items-center justify-center text-white font-bold text-xl">Ch</div>
          <div>
            <h1 className="text-xl font-extrabold">Estudos Químicos</h1>
            <p className="text-sm text-gray-600 dark:text-gray-300">Aprende química com lições, tabela periódica interativa e quizzes.</p>
          </div>
        </div>

        <nav className="flex items-center gap-3">
          <NavButton active={view==='home'} onClick={()=>setView('home')}>Início</NavButton>
          <NavButton active={view==='table'} onClick={()=>setView('table')}>Tabela</NavButton>
          <NavButton active={view==='lessons'} onClick={()=>setView('lessons')}>Lições</NavButton>
          <NavButton active={view==='quiz'} onClick={()=>setView('quiz')}>Quiz</NavButton>
          <NavButton active={view==='flashcards'} onClick={()=>setView('flashcards')}>Flashcards</NavButton>
          <button onClick={()=>setDark(d=>!d)} className="ml-2 p-2 rounded-md bg-white/60 dark:bg-black/40"> {dark ? '🌙' : '☀️'} </button>
        </nav>
      </header>

      <main className="max-w-6xl mx-auto p-4">
        {view==='home' && <Home setView={setView} />}
        {view==='table' && <PeriodicTable elements={periodic} onSelect={(e)=>setSelected(e)} />}
        {view==='lessons' && <Lessons />}
        {view==='quiz' && <Quiz />}
        {view==='flashcards' && <Flashcards />}
      </main>

      <footer className="max-w-6xl mx-auto p-6 text-center text-xs text-gray-500 dark:text-gray-400">
        Feito com ❤ — Estuda e diverte-te!
      </footer>

      {selected && <ElementModal element={selected} onClose={()=>setSelected(null)} />}
    </div>
  );
}

function NavButton({children, active, onClick}) {
  return (
    <button onClick={onClick} className={`px-3 py-2 rounded-md text-sm font-medium ${active ? 'bg-indigo-600 text-white' : 'text-gray-700 dark:text-gray-200 bg-white/40 dark:bg-black/20'}`}>
      {children}
    </button>
  );
}

function Home({setView}) {
  return (
    <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="md:col-span-2 p-6 rounded-2xl bg-white dark:bg-gray-800 shadow">
        <h2 className="text-2xl font-bold mb-2">Bem-vindo(a) aos Estudos Químicos</h2>
        <p className="text-gray-700 dark:text-gray-300 mb-4">Explora a tabela periódica, aprende com lições e testa os teus conhecimentos com quizzes.</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Card title="Lições" subtitle="Explicações passo a passo" onClick={()=>setView('lessons')} />
          <Card title="Tabela Periódica" subtitle="Explora elementos" onClick={()=>setView('table')} />
          <Card title="Quiz" subtitle="Testa o que aprendeste" onClick={()=>setView('quiz')} />
          <Card title="Flashcards" subtitle="Revisões rápidas" onClick={()=>setView('flashcards')} />
        </div>
      </div>

      <aside className="p-6 rounded-2xl bg-gradient-to-br from-indigo-50 to-fuchsia-50 dark:from-indigo-900 dark:to-fuchsia-900">
        <h3 className="font-semibold mb-2">Conselho do dia</h3>
        <p className="text-sm text-gray-700 dark:text-gray-200">Estuda em blocos de 25 minutos com 5 minutos de pausa (Técnica Pomodoro).</p>
      </aside>
    </section>
  );
}

function Card({title, subtitle, onClick}) {
  return (
    <button onClick={onClick} className="p-4 rounded-xl bg-white dark:bg-gray-700 shadow text-left">
      <h4 className="font-semibold">{title}</h4>
      <p className="text-sm text-gray-600 dark:text-gray-300">{subtitle}</p>
    </button>
  );
}

function PeriodicTable({elements, onSelect}) {
  return (
    <section>
      <h2 className="text-xl font-bold mb-3">Tabela Periódica</h2>
      <div className="grid grid-cols-18 gap-2">
        {elements.map(el => (
          <div key={el.number} onClick={()=>onSelect(el)} className="cursor-pointer p-3 rounded-lg bg-white dark:bg-gray-800 shadow text-center">
            <div className="text-sm text-gray-500 dark:text-gray-400">{el.number}</div>
            <div className="text-2xl font-bold">{el.symbol}</div>
            <div className="text-xs mt-1">{el.name}</div>
          </div>
        ))}
      </div>
      <p className="mt-4 text-sm text-gray-600 dark:text-gray-300">Clica num elemento para ver detalhes.</p>
    </section>
  );
}

function ElementModal({element, onClose}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative p-6 bg-white dark:bg-gray-800 rounded-2xl shadow max-w-md w-full">
        <button onClick={onClose} className="absolute top-3 right-3 text-sm">Fechar ✖</button>
        <div className="text-center">
          <div className="text-6xl font-extrabold">{element.symbol}</div>
          <div className="text-xl font-semibold">{element.name}</div>
          <div className="text-sm text-gray-600 dark:text-gray-300">Número atômico: {element.number}</div>
          <div className="text-sm text-gray-600 dark:text-gray-300">Massa atómica: {element.mass || '—'}</div>
          <div className="mt-4 text-left">
            <h4 className="font-semibold">Sobre</h4>
            <p className="text-sm text-gray-700 dark:text-gray-200">Propriedades, ocorrência e aplicações deste elemento.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Lessons() {
  const lessons = [
    {id:1, title:'Átomos e Elementos', summary:'Estrutura atómica, prótons, neutrões e eletrões.'},
    {id:2, title:'Tabela Periódica', summary:'Organização e tendências periódicas.'},
    {id:3, title:'Ligações Químicas', summary:'Iónica, covalente e metálica.'},
  ];
  return (
    <section>
      <h2 className="text-xl font-bold mb-4">Lições</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {lessons.map(l => (
          <article key={l.id} className="p-4 rounded-xl bg-white dark:bg-gray-800 shadow">
            <h3 className="font-semibold">{l.title}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-300">{l.summary}</p>
            <details className="mt-2"><summary className="cursor-pointer">Abrir aula</summary>
              <div className="mt-2 text-sm text-gray-700 dark:text-gray-200">Conteúdo detalhado e exercícios.</div>
            </details>
          </article>
        ))}
      </div>
    </section>
  );
}

function Quiz() {
  const questions = [
    {q:'Qual o número atômico do Oxigénio?', options:[6,7,8,9], a:8},
    {q:'Que tipo de ligação existe entre Na e Cl?', options:['Covalente','Iónica','Metálica','De hidrogênio'], a:'Iónica'}
  ];
  const [index,setIndex] = React.useState(0);
  const [score,setScore] = React.useState(0);
  const [done,setDone] = React.useState(false);

  function answer(choice) {
    const correct = questions[index].a;
    if (choice === correct) setScore(s=>s+1);
    const next = index+1;
    if (next >= questions.length) setDone(true);
    else setIndex(next);
  }

  if (done) return <div className="p-6 rounded-xl bg-white dark:bg-gray-800 shadow"><h3 className="text-xl font-bold">Resultados</h3><p className="mt-2">Pontuação: {score} / {questions.length}</p></div>;

  const q = questions[index];
  return (
    <div className="p-6 rounded-xl bg-white dark:bg-gray-800 shadow">
      <h3 className="font-semibold">Pergunta {index+1} / {questions.length}</h3>
      <p className="mt-2">{q.q}</p>
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
        {q.options.map((opt,i)=> <button key={i} onClick={()=>answer(opt)} className="p-3 rounded-lg bg-indigo-50 dark:bg-indigo-900 text-left">{opt}</button>)}
      </div>
    </div>
  );
}

function Flashcards() {
  const cards = [
    {q:'O que é um protão?', a:'Partícula subatómica com carga positiva no núcleo.'},
    {q:'Símbolo do Sódio?', a:'Na'},
    {q:'Ligação covalente?', a:'Partilha de pares de eletrões.'}
  ];
  const [i,setI] = React.useState(0);
  const [show,setShow] = React.useState(false);
  function next(){ setShow(false); setI((x)=> (x+1) % cards.length); }
  return (
    <div className="p-6 rounded-xl bg-white dark:bg-gray-800 shadow text-center">
      <h3 className="font-semibold mb-4">Flashcard {i+1} / {cards.length}</h3>
      <div className="p-6 rounded-lg bg-gray-50 dark:bg-gray-700 cursor-pointer" onClick={()=>setShow(s=>!s)}>
        {!show ? <div className="text-lg">{cards[i].q}</div> : <div className="text-lg font-medium">{cards[i].a}</div>}
      </div>
      <div className="mt-4 flex justify-center gap-2">
        <button onClick={()=>setI(x=> (x-1+cards.length)%cards.length)} className="px-3 py-2 rounded-md bg-white/60">Anterior</button>
        <button onClick={next} className="px-3 py-2 rounded-md bg-indigo-600 text-white">Próximo</button>
      </div>
    </div>
  );
}
